package com.kv.motest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.actionbarsherlock.app.SherlockListActivity;

public class ExamActicity extends SherlockListActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_exam);
		String[] arr = { "Test1", "Test2", "Gate Test 1", "Gate Test 2", "Gate Test 3", "Gate Test 4", "Gate Test 5" };
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_exam_row, R.id.text, arr);
		setListAdapter(adapter);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		Intent intent = new Intent(this, StartTestActivity.class);
		startActivity(intent);
		finish();
	}
}
