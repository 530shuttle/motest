package com.kv.motest;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.ScrollView;
import android.widget.TextView;

import com.actionbarsherlock.app.ActionBar;
import com.actionbarsherlock.app.SherlockActivity;
import com.kv.motest.db.QuesDao;
import com.kv.motest.db.model.Question;
import com.kv.motest.util.ScoreCalculator;

public class QuestionActivity extends SherlockActivity {
	private static final long TEST_TIME = 20 * 60 * 1000;
	private static final String KEY_TIME = "TIME_Start";

	private TextView tvQuestion;
	private RadioButton radioOne;
	private RadioButton radioTwo;
	private RadioButton radioThree;
	private RadioButton radioFour;
	private int quesIndex = 0;
	private ArrayList<Question> questions;
	private Button prevButton;
	private Button nextButton;
	private ScrollView mScrollView;
	private RadioGroup mRadioGroup;
	private ActionBar actionBar;
	private CountDownTimer timer;
	private long startTime = 0l;
	private long testId;
	private int clicks = 0;
	private long timeTaken = 0;
	private QuesDao dao;
	private Handler handler = new Handler();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (savedInstanceState != null) {
			startTime = savedInstanceState.getLong(KEY_TIME);
			quesIndex = savedInstanceState.getInt("index");
		}
		testId = getIntent().getLongExtra("testId", -1);
		System.out.println(testId);
		setContentView(R.layout.activity_question_test);
		tvQuestion = (TextView) findViewById(R.id.tv_question);
		radioOne = (RadioButton) findViewById(R.id.radio1);
		radioTwo = (RadioButton) findViewById(R.id.radio2);
		radioThree = (RadioButton) findViewById(R.id.radio3);
		radioFour = (RadioButton) findViewById(R.id.radio4);
		prevButton = (Button) findViewById(R.id.btn_prev);
		nextButton = (Button) findViewById(R.id.btn_next);
		mScrollView = (ScrollView) findViewById(R.id.scrollQues);
		tvQuestion.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

		mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup1);
		dao = new QuesDao(this);
		questions = dao.getAllQuestions();

		mRadioGroup.setOnCheckedChangeListener(onOptionChanged);

		actionBar = getSupportActionBar();
		View t = getLayoutInflater().inflate(R.layout.timer_bar, null, false);
		ActionBar.LayoutParams params = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT,
				ActionBar.LayoutParams.MATCH_PARENT, Gravity.CENTER);
		actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
		actionBar.setCustomView(t, params);
		final TextView tvTime = (TextView) t.findViewById(R.id.tv_time_counter);
		Typeface tf = Typeface.createFromAsset(getAssets(), "digital.ttf");
		tvTime.setTypeface(tf);
		long temp = 0;
		if (startTime == 0) {
			startTime = System.currentTimeMillis();
		} else {
			temp = System.currentTimeMillis() - startTime;
		}
		timer = new CountDownTimer(TEST_TIME - temp, 1000) {

			@Override
			public void onTick(long milli) {
				int sec = (int) (milli / 1000);
				int min = (int) (sec / 60);
				sec = sec % 60;
				tvTime.setText(String.format("%d:%02d", min, sec));
			}

			@Override
			public void onFinish() {
				tvTime.setText("Time Up!");
				confirmTest();
			}

		}.start();

	}

	@Override
	protected void onResume() {
		super.onResume();
		if (quesIndex == 0) {
			prevButton.setEnabled(false);
		}
		setQuestionText();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putInt("index", quesIndex);
		outState.putLong(KEY_TIME, startTime);
	}

	private OnCheckedChangeListener onOptionChanged = new OnCheckedChangeListener() {

		public void onCheckedChanged(RadioGroup group, int checkedId) {
			Question q = questions.get(quesIndex);
			long t = System.currentTimeMillis() - timeTaken;
			switch (checkedId) {
			case R.id.radio1:
				q.setSelectedIndex(q.getOptionOne().getId());
				q.incNoOfClicks();
				q.incTimeTaken(t);
				if (q.getAnswer().getId() == q.getOptionOne().getId()) {
					q.setCorrect(true);
				}
				break;
			case R.id.radio2:
				q.setSelectedIndex(q.getOptionTwo().getId());
				q.incNoOfClicks();
				q.incTimeTaken(t);
				if (q.getAnswer().getId() == q.getOptionTwo().getId()) {
					q.setCorrect(true);
				}
				break;
			case R.id.radio3:
				q.setSelectedIndex(q.getOptionThree().getId());
				q.incNoOfClicks();
				q.incTimeTaken(t);
				if (q.getAnswer().getId() == q.getOptionThree().getId()) {
					q.setCorrect(true);
				}
				break;
			case R.id.radio4:
				q.setSelectedIndex(q.getOptionFour().getId());
				q.incNoOfClicks();
				q.incTimeTaken(t);
				if (q.getAnswer().getId() == q.getOptionFour().getId()) {
					q.setCorrect(true);
				}
				break;
			case -1:
				break;
			default:
				break;
			}

		}
	};

	private void setQuestionText() {
		Question q = questions.get(quesIndex);
		String qq = "Q." + (quesIndex + 1) + ": " + q.getQuesion();
		tvQuestion.setText(qq);
		radioOne.setText(q.getOptionOne().getText());
		radioTwo.setText(q.getOptionTwo().getText());
		radioThree.setText(q.getOptionThree().getText());
		radioFour.setText(q.getOptionFour().getText());
		int in = q.getSelectedIndex();
		if (in == q.getOptionOne().getId()) {
			radioOne.setChecked(true);
		} else if (in == q.getOptionTwo().getId()) {
			radioTwo.setChecked(true);
		} else if (in == q.getOptionThree().getId()) {
			radioThree.setChecked(true);
		} else if (in == q.getOptionFour().getId()) {
			radioFour.setChecked(true);
		}
		timeTaken = System.currentTimeMillis();
	}

	public void onClickPrev(View v) {
		resetView();
		if (quesIndex == questions.size() - 1) {
			nextButton.setId(R.id.btn_next);
			nextButton.setText("Next");
		}
		quesIndex--;

		if (quesIndex == 0) {
			prevButton.setEnabled(false);
		}
		setQuestionText();

	}

	public void onClickNext(View v) {
		if (v.getId() == R.id.btn_finish) {
			finishTest();
			return;
		}
		resetView();
		if (quesIndex == 0) {
			prevButton.setEnabled(true);
		}
		quesIndex++;

		if (quesIndex == questions.size() - 1) {
			nextButton.setText("Finish");
			nextButton.setId(R.id.btn_finish);
		}
		setQuestionText();

		System.out.println(mRadioGroup.getCheckedRadioButtonId());
	}

	private void resetView() {
		mScrollView.smoothScrollTo(0, 0);
		mRadioGroup.clearCheck();
		clicks = 0;
	}

	private void finishTest() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("Do you want to submit test");
		builder.setPositiveButton("OK", new OnClickListener() {

			public void onClick(DialogInterface dialog, int which) {
				confirmTest();
				dialog.cancel();
			}
		}).setNegativeButton("Cancel", new OnClickListener() {

			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		}).create();
		builder.show();
	}

	private void confirmTest() {
		questions = ScoreCalculator.calculateScore(questions);
		handler.post(submitTestAsyc);
		Intent i = new Intent(QuestionActivity.this, TestResultActivity.class);
		i.putParcelableArrayListExtra("output", questions);
		i.putExtra("testId", testId);
		i.putExtra("totalTime", System.currentTimeMillis() - startTime);
		startActivity(i);
		finish();
	}

	private Runnable submitTestAsyc = new Runnable() {

		public void run() {
			dao.submitTest(questions, testId, System.currentTimeMillis() - startTime);
		}
	};
}
