package com.kv.motest.listadapter;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.kv.motest.R;
import com.kv.motest.db.model.TestResult;

public class TestListAdapter extends ArrayAdapter<TestResult> {
	private LayoutInflater inflater;

	public TestListAdapter(Context context, int textViewResourceId, List<TestResult> objects) {
		super(context, textViewResourceId, objects);
		inflater = LayoutInflater.from(context);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder = null;
		if (null == convertView) {
			convertView = inflater.inflate(R.layout.list_test_result_row, parent, false);
			holder = new ViewHolder();
			holder.tvId = (TextView) convertView.findViewById(R.id.row_test_id);
			holder.tvScore = (TextView) convertView.findViewById(R.id.row_score);
			holder.tvDate = (TextView) convertView.findViewById(R.id.row_date_time);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		TestResult r = getItem(position);
		holder.tvId.setText("Test id - " + r.getId());
		holder.tvScore.setText("Score :" + r.getTotalScore());
		Date t = new Date(r.getDateTime());
		DateFormat df = DateFormat.getDateTimeInstance();
		holder.tvDate.setText("Time : " + df.format(t));
		return convertView;
	}

	private static class ViewHolder {
		TextView tvId;
		TextView tvScore;
		TextView tvDate;
	}
}
