package com.kv.motest;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;

import com.actionbarsherlock.app.SherlockActivity;
import com.kv.motest.db.model.Question;
import com.kv.motest.util.ScoreCalculator;

public class ReviewActivity extends SherlockActivity {
	private ArrayList<Question> questions;
	private double minScore = 0.0;
	private int maxScore;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_review);
		questions = getIntent().getParcelableArrayListExtra("output");
		maxScore = questions.size()*ScoreCalculator.MAX_SCORE;
		for(Question q : questions){
			minScore += q.getScore();
		}
	}
}
