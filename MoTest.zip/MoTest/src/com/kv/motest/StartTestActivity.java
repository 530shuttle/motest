package com.kv.motest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockActivity;
import com.kv.motest.db.QuesDao;

public class StartTestActivity extends SherlockActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_start_test);
		TextView ins1 = (TextView) findViewById(R.id.ins1);
		ins1.setText("Total number of questions : 20");
		TextView ins2 = (TextView) findViewById(R.id.ins2);
		ins2.setText("Time alloted : 20 minutes.");
		TextView ins3 = (TextView) findViewById(R.id.ins3);
		ins3.setText("Each question carry 4 mark, no negative marks.");
	}

	public void onClickStartTest(View v) {
		v.setEnabled(false);
		QuesDao dao = new QuesDao(this);
		long testId = dao.startNewTest();
		Intent intent = new Intent(this, QuestionActivity.class);
		intent.putExtra("testId", testId);
		startActivity(intent);
		finish();
	}

}
