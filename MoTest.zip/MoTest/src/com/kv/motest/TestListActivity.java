package com.kv.motest;

import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.actionbarsherlock.app.SherlockListActivity;
import com.kv.motest.db.QuesDao;
import com.kv.motest.db.model.TestResult;
import com.kv.motest.listadapter.TestListAdapter;
import com.kv.motest.util.ScoreCalculator;

public class TestListActivity extends SherlockListActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		List<TestResult> results = new QuesDao(this).getTestResults();
		ListAdapter adapt = new TestListAdapter(this, 0, results);
		setListAdapter(adapt);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);
		TestResult r = (TestResult) l.getAdapter().getItem(position);
		Intent intent = new Intent(this, TestResultActivity.class);
		intent.putExtra("testId", r.getId());
		intent.putExtra("totalTime", r.getTotalTime());
		intent.putExtra("maxScore", r.getTotalQues() * ScoreCalculator.MAX_SCORE);
		intent.putExtra("minScore", r.getTotalScore());
		intent.putExtra("totalAns", r.getTotalAns());
		intent.putExtra("correctAns", r.getCorrectAns());
		intent.putExtra("totalQues", r.getTotalQues());
		startActivity(intent);
	}

	public void onClickReview(View v) {
		// Intent i = new Intent(this, ReviewActivity.class);
		// i.putParcelableArrayListExtra("output", questions);
		// i.putExtra("testId", testId);
		// i.putExtra("totalTime", totalTime);
		// startActivity(i);
		// finish();
	}
}
