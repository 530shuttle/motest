package com.kv.motest.db.model;

public class TestResult {
	private long id;
	private long dateTime;;
	private int totalQues;
	private long totalTime;
	private int totalAns;
	private int correctAns;
	private double totalScore;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getDateTime() {
		return dateTime;
	}

	public void setDateTime(long dateTime) {
		this.dateTime = dateTime;
	}

	public int getTotalQues() {
		return totalQues;
	}

	public void setTotalQues(int totalQues) {
		this.totalQues = totalQues;
	}

	public long getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(long totalTime) {
		this.totalTime = totalTime;
	}

	public int getCorrectAns() {
		return correctAns;
	}

	public void setCorrectAns(int correctAns) {
		this.correctAns = correctAns;
	}

	public double getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(double totalScore) {
		this.totalScore = totalScore;
	}

	public int getTotalAns() {
		return totalAns;
	}

	public void setTotalAns(int totalAns) {
		this.totalAns = totalAns;
	}

}
