package com.kv.motest.db.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Question implements Parcelable {
	private long _id;
	private String quesion;
	private Option optionOne;
	private Option optionTwo;
	private Option optionThree;
	private Option optionFour;
	private Option answer;
	private int selectedIndex;
	private int noOfClicks = -1;
	private long timeTaken = 0;
	private boolean isCorrect;
	private double score;

	public Question() {
		// TODO Auto-generated constructor stub
	}

	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeLong(_id);
		dest.writeString(quesion);
		dest.writeInt(selectedIndex);
		dest.writeInt(noOfClicks);
		dest.writeLong(timeTaken);
		dest.writeByte((byte) (isCorrect ? 1 : 0));
		dest.writeDouble(score);
	}

	private Question(Parcel in) {
		_id = in.readLong();
		quesion = in.readString();
		selectedIndex = in.readInt();
		noOfClicks = in.readInt();
		timeTaken = in.readLong();
		isCorrect = in.readByte() == 1;
		score = in.readDouble();
	}

	public static final Parcelable.Creator<Question> CREATOR = new Creator<Question>() {

		public Question[] newArray(int size) {
			return new Question[size];
		}

		public Question createFromParcel(Parcel source) {
			return new Question(source);
		}
	};

	public long get_id() {
		return _id;
	}

	public void set_id(long _id) {
		this._id = _id;
	}

	public String getQuesion() {
		return quesion;
	}

	public void setQuesion(String quesion) {
		this.quesion = quesion;
	}

	public Option getOptionOne() {
		return optionOne;
	}

	public void setOptionOne(Option optionOne) {
		this.optionOne = optionOne;
	}

	public Option getOptionTwo() {
		return optionTwo;
	}

	public void setOptionTwo(Option optionTwo) {
		this.optionTwo = optionTwo;
	}

	public Option getOptionThree() {
		return optionThree;
	}

	public void setOptionThree(Option optionThree) {
		this.optionThree = optionThree;
	}

	public Option getOptionFour() {
		return optionFour;
	}

	public void setOptionFour(Option optionFour) {
		this.optionFour = optionFour;
	}

	public Option getAnswer() {
		return answer;
	}

	public void setAnswer(Option answer) {
		this.answer = answer;
	}

	public int getSelectedIndex() {
		return selectedIndex;
	}

	public void setSelectedIndex(int selectedIndex) {
		this.selectedIndex = selectedIndex;
	}

	public int getNoOfClicks() {
		return noOfClicks;
	}

	public void setNoOfClicks(int noOfClicks) {
		this.noOfClicks = noOfClicks;
	}

	public void incNoOfClicks() {
		this.noOfClicks += 1;
	}

	public long getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(long timeTaken) {
		this.timeTaken = timeTaken;
	}

	public void incTimeTaken(long timeTaken) {
		this.timeTaken += timeTaken;
	}

	public boolean isCorrect() {
		return isCorrect;
	}

	public void setCorrect(boolean isCorrect) {
		this.isCorrect = isCorrect;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

}
