package com.kv.motest.db;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.kv.motest.db.model.Option;
import com.kv.motest.db.model.Question;
import com.kv.motest.db.model.TestResult;

public class QuesDao {
	private DbHelper dbHelper;
	private Cursor mCursor;
	private SQLiteDatabase db;

	public QuesDao(Context context) {
		dbHelper = new DbHelper(context);
	}

	public ArrayList<Question> getAllQuestions() {
		ArrayList<Question> questions = null;
		Cursor tempCursor;
		try {
			db = dbHelper.getReadableDatabase();
			mCursor = db.rawQuery("select * from question_master", null);
			if (mCursor.moveToFirst()) {
				questions = new ArrayList<Question>();
				do {
					Question q = new Question();
					q.set_id(mCursor.getLong(0));
					q.setQuesion(mCursor.getString(1).trim());
					int oneId = mCursor.getInt(2);
					tempCursor = db.rawQuery("select * from answer_options where _id=" + oneId, null);
					if (tempCursor.moveToFirst()) {
						q.setOptionOne(new Option(oneId, tempCursor.getString(1).trim()));
					}
					tempCursor.close();
					oneId = mCursor.getInt(3);
					tempCursor = db.rawQuery("select * from answer_options where _id=" + oneId, null);
					if (tempCursor.moveToFirst()) {
						q.setOptionTwo(new Option(oneId, tempCursor.getString(1).trim()));
					}
					tempCursor.close();
					oneId = mCursor.getInt(4);
					tempCursor = db.rawQuery("select * from answer_options where _id=" + oneId, null);
					if (tempCursor.moveToFirst()) {
						q.setOptionThree(new Option(oneId, tempCursor.getString(1).trim()));
					}
					tempCursor.close();
					oneId = mCursor.getInt(5);
					tempCursor = db.rawQuery("select * from answer_options where _id=" + oneId, null);
					if (tempCursor.moveToFirst()) {
						q.setOptionFour(new Option(oneId, tempCursor.getString(1).trim()));
					}
					tempCursor.close();
					oneId = mCursor.getInt(6);
					tempCursor = db.rawQuery("select * from answer_options where _id=" + oneId, null);
					if (tempCursor.moveToFirst()) {
						q.setAnswer(new Option(oneId, tempCursor.getString(1).trim()));
					}
					tempCursor.close();
					questions.add(q);
				} while (mCursor.moveToNext());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (db != null) {
				db.close();
			}
			if (mCursor != null) {
				mCursor.close();
			}
		}
		return questions;
	}

	public long startNewTest() {
		long scoreId = -1l;
		try {
			db = dbHelper.getWritableDatabase();
			dbHelper.copyDb();
			ContentValues cv = new ContentValues();
			cv.put(ScoreTable.DATE_TIME, System.currentTimeMillis());

			scoreId = db.insert(ScoreTable.TABLE_NAME, null, cv);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (db != null) {
				db.close();
			}
		}
		return scoreId;
	}

	public void submitTest(List<Question> questions, long testId, long timeTaken) {
		int correctCount = 0;
		int totalAns = 0;
		double score = 0.0;
		try {
			db = dbHelper.getWritableDatabase();
			for (Question q : questions) {
				if (q.isCorrect()) {
					correctCount++;
					score += q.getScore();
				}
				if (q.getSelectedIndex() > 0) {
					totalAns++;
				}
				ContentValues cv = new ContentValues();
				cv.put(ScoreDetailTable.SCORE_ID, testId);
				cv.put(ScoreDetailTable.QUES_ID, q.get_id());
				cv.put(ScoreDetailTable.ANS_ID, q.getSelectedIndex());
				cv.put(ScoreDetailTable.IS_CORRECT, q.isCorrect());
				cv.put(ScoreDetailTable.NO_OF_CLICK, q.getNoOfClicks());
				cv.put(ScoreDetailTable.TIME_TAKEN, q.getTimeTaken());
				cv.put(ScoreDetailTable.POINTS, q.getScore());

				db.insert(ScoreDetailTable.TABLE_NAME, null, cv);
			}
			ContentValues cv = new ContentValues();
			cv.put(ScoreTable.CORRECT_ANS, correctCount);
			cv.put(ScoreTable.TOTAL_TIME, timeTaken);
			cv.put(ScoreTable.TOTAL_QUES, questions.size());
			cv.put(ScoreTable.TOTAL_ANS, totalAns);
			cv.put(ScoreTable.TOTAL_SCORE, score);
			db.update(ScoreTable.TABLE_NAME, cv, "_id=?", new String[] { Long.toString(testId) });
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (db != null) {
				db.close();
			}
		}
	}

	public List<TestResult> getTestResults() {
		List<TestResult> results = new ArrayList<TestResult>();
		try {
			db = dbHelper.getReadableDatabase();
			mCursor = db.rawQuery("select * from " + ScoreTable.TABLE_NAME + " where " + ScoreTable.TOTAL_TIME + ">1", null);
			if (mCursor != null && mCursor.moveToFirst()) {
				do {
					TestResult r = new TestResult();
					r.setId(mCursor.getLong(mCursor.getColumnIndex(ScoreTable._ID)));
					r.setDateTime(mCursor.getLong(mCursor.getColumnIndex(ScoreTable.DATE_TIME)));
					r.setTotalQues(mCursor.getInt(mCursor.getColumnIndex(ScoreTable.TOTAL_QUES)));
					r.setTotalScore(mCursor.getDouble(mCursor.getColumnIndex(ScoreTable.TOTAL_SCORE)));
					r.setTotalTime(mCursor.getLong(mCursor.getColumnIndex(ScoreTable.TOTAL_TIME)));
					r.setCorrectAns(mCursor.getInt(mCursor.getColumnIndex(ScoreTable.CORRECT_ANS)));
					r.setTotalAns(mCursor.getInt(mCursor.getColumnIndex(ScoreTable.TOTAL_ANS)));
					results.add(r);
				} while (mCursor.moveToNext());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (db != null) {
				db.close();
			}
			if (mCursor != null) {
				mCursor.close();
			}
		}
		return results;
	}
}
