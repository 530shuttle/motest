package com.kv.motest.db;

import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;

public class ScoreTable implements BaseColumns {
	public static final String TABLE_NAME = "score";
	public static final String DATE_TIME = "datetime";
	public static final String TOTAL_TIME = "total_time";
	public static final String TOTAL_QUES = "total_ques";
	public static final String TOTAL_ANS = "total_ans";
	public static final String CORRECT_ANS = "correct_ans";
	public static final String TOTAL_SCORE = "total_score";

	private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
												+ _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
												+ DATE_TIME + " INTEGER, "
												+ TOTAL_TIME + " INTEGER, "
												+ TOTAL_SCORE + " REAL, "
												+ TOTAL_QUES + " INTEGER, "
												+ TOTAL_ANS + " INTEGER, "
												+ CORRECT_ANS + " INTEGER "
												+ ");";

	public static void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_TABLE);
	}

	public static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	}
}
