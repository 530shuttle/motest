package com.kv.motest.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

public class DbHelper extends SQLiteOpenHelper {
	private static final String DB_PATH = "/data/data/com.kv.motest/databases/";

	public static final String DB_NAME = "MOTEST.db";
	private static final int DB_VERSION = 3;
	private SQLiteDatabase myDataBase;

	private final Context myContext;

	public DbHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
		Log.d("test", "db helper called");
		this.myContext = context;
		try {
			createDataBase();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
		}
	}

	public void createDataBase() throws IOException {
		boolean dbExits = checkFile();

		if (dbExits) {

		} else {
			try {
				copyDataBase();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// copyDb();
	}

	public void copyDb() {
		InputStream is = null;
		OutputStream os = null;
		try {
			String in = DB_PATH + DB_NAME;
			is = new FileInputStream(in);

			os = new FileOutputStream(Environment.getExternalStorageDirectory()
					.getAbsolutePath() + "/" + DB_NAME);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				os.flush();
				os.close();
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	public DbHelper openDB() throws SQLException {

		myDataBase = this.getWritableDatabase();
		return this;
	}

	private void copyDataBase() {
		openDB();
		InputStream is = null;
		OutputStream os = null;
		try {
			is = myContext.getAssets().open(DB_NAME);

			String out = DB_PATH + DB_NAME;
			os = new FileOutputStream(out);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (myDataBase.isOpen())
				myDataBase.close();
			try {
				os.flush();
				os.close();
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	@SuppressWarnings("unused")
	private boolean checkDataBase() {
		SQLiteDatabase checkDB = null;

		try {
			if (checkFile()) {
				String myPath = DB_PATH + DB_NAME;
				checkDB = SQLiteDatabase.openDatabase(myPath, null,
						SQLiteDatabase.OPEN_READONLY);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (checkDB != null) {
			checkDB.close();
		}
		return checkDB != null ? true : false;
	}

	private boolean checkFile() {
		File dbFile = new File(DB_PATH + DB_NAME);
		return dbFile.exists();
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		ScoreTable.onCreate(db);
		ScoreDetailTable.onCreate(db);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		ScoreTable.onUpgrade(db, oldVersion, newVersion);
		ScoreDetailTable.onUpgrade(db, oldVersion, newVersion);
	}

}
