package com.kv.motest.db;

import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;

public class ScoreDetailTable implements BaseColumns {
	public static final String TABLE_NAME = "score_detail";
	public static final String SCORE_ID = "score_id";
	public static final String QUES_ID = "ques_id";
	public static final String ANS_ID = "ans_id";
	public static final String IS_CORRECT = "is_correct";
	public static final String TIME_TAKEN = "time_taken";
	public static final String NO_OF_CLICK = "clicks";
	public static final String POINTS = "points";

	private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
												+ _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
												+ SCORE_ID + " INTEGER, "
												+ QUES_ID + " INTEGER, "
												+ ANS_ID + " INTEGER, "
												+ IS_CORRECT + " BOOLEAN, "
												+ TIME_TAKEN + " INTEGER, "
												+ NO_OF_CLICK + " INTEGER, "
												+ POINTS + " REAL "
												+ ");";

	public static void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_TABLE);
	}

	public static void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("drop table if exists " + TABLE_NAME);
		db.execSQL(CREATE_TABLE);
	}

}
