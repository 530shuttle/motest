package com.kv.motest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
	private TextView tUserName;
	private TextView tPassword;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		tUserName = (TextView) findViewById(R.id.tv_user_name);
		tPassword = (TextView) findViewById(R.id.tv_password);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_login, menu);
		return true;
	}

	public void onClickLoginButton(View v) {
		String user = tUserName.getText().toString();
		String key = tPassword.getText().toString();
		if (user.length() < 1) {
			tUserName.requestFocus();
			tUserName.setError("Username Empty");
			return;
		}
		if (key.length() < 1) {
			tPassword.requestFocus();
			tPassword.setError("Password Empty");
			return;
		}
		if (user.equals(key) && user.equals("admin")) {
			Intent i = new Intent(this, HomeActivity.class);
			startActivity(i);
			finish();
		} else {
			tUserName.setText("");
			tPassword.setText("");
			Toast.makeText(this, "Wrong user name or password", Toast.LENGTH_SHORT).show();
		}

	}
}
