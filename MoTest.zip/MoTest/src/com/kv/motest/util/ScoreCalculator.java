package com.kv.motest.util;

import java.util.ArrayList;

import com.kv.motest.db.model.Question;

public class ScoreCalculator {
	public static final int MAX_SCORE = 4;

	public static ArrayList<Question> calculateScore(ArrayList<Question> questions) {

		for (Question q : questions) {
			long t = q.getTimeTaken() / 1000;
			int c = q.getNoOfClicks();
			double s = 0.0;
			if (q.isCorrect()) {
				if (c == 1 && t <= 60) {
					s = 4.0;
				} else if (c == 2 && t <= 60) {
					s = 3.5;
				} else if (c == 3 && t <= 60 || c == 1 && t > 60) {
					s = 3.0;
				} else if (c >= 4 && t <= 60 || c == 2 && t > 60) {
					s = 2.5;
				} else if (c >= 4 && t > 60) {
					s = 1.5;
				}
			}
			q.setScore(s);
		}
		return questions;
	}

}
