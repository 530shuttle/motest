package com.kv.motest;

import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.actionbarsherlock.app.SherlockActivity;
import com.kv.motest.db.model.Question;
import com.kv.motest.util.ScoreCalculator;

public class TestResultActivity extends SherlockActivity {

	private ArrayList<Question> questions;
	private double minScore = 0.0;
	private int maxScore;
	private long testId;
	private int totalAns = 0;
	private int correctAns = 0;
	private long totalTime;
	private int totalQues;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test_result);
		Intent intent = getIntent();
		testId = intent.getLongExtra("testId", 0);
		totalTime = intent.getLongExtra("totalTime", 0);
		questions = intent.getParcelableArrayListExtra("output");
		if (questions == null) {
			maxScore = intent.getIntExtra("maxScore", 0);
			minScore = intent.getDoubleExtra("minScore", 0);
			totalAns = intent.getIntExtra("totalAns", 0);
			correctAns = intent.getIntExtra("correctAns", 0);
			totalQues = intent.getIntExtra("totalQues", 0);
		} else {
			totalQues = questions.size();
			maxScore = questions.size() * ScoreCalculator.MAX_SCORE;
			for (Question q : questions) {
				minScore += q.getScore();
				if (q.getSelectedIndex() > 0) {
					totalAns++;
				}
				if (q.isCorrect()) {
					correctAns++;
				}
			}
		}

		((TextView) findViewById(R.id.test_id)).setText(Long.toString(testId));
		((TextView) findViewById(R.id.test_score)).setText(((int) minScore) + "/" + maxScore);
		((TextView) findViewById(R.id.test_ques)).setText(Integer.toString(totalQues));
		((TextView) findViewById(R.id.total_ans)).setText(Integer.toString(totalAns));
		((TextView) findViewById(R.id.correct_ans)).setText(Integer.toString(correctAns));
		int sec = (int) (totalTime / 1000);
		int min = (int) (sec / 60);
		sec = sec % 60;
		((TextView) findViewById(R.id.total_time)).setText(String.format("%d:%02d", min, sec));
	}

	public void onClickReview(View v) {
		// Intent i = new Intent(this, ReviewActivity.class);
		// i.putParcelableArrayListExtra("output", questions);
		// i.putExtra("testId", testId);
		// i.putExtra("totalTime", totalTime);
		// startActivity(i);
		// finish();
	}
}
