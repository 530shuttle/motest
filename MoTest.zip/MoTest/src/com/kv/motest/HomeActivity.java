package com.kv.motest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.actionbarsherlock.app.SherlockActivity;

public class HomeActivity extends SherlockActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
	}

	public void onClickFeature(View v) {
		Intent i = null;
		switch (v.getId()) {
		case R.id.home_btn_exam:
			i = new Intent(this, ExamActicity.class);
			break;
		case R.id.home_btn_result:
			i = new Intent(this, TestListActivity.class);
			break;
		default:
			break;
		}
		if (i != null) {
			startActivity(i);
		}

	}
}
